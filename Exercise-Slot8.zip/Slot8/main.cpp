#include <iostream>
using namespace std;
void sapxep();
void sapxep(){
    cout<<"Nhap mang: "<<endl;
    //1. nhap mang
    int mang[6];
    for(int i=0;i<6;i++){
        cin>>mang[i];
    }
    //2. doi cho
    for(int i=0;i<6;i++){
        for(int j=0;j<6;j++){
            int tam;
            if(mang[i]>mang[j]){
                tam=mang[i];
                mang[i]=mang[j];
                mang[j]=tam;
            }
        }
    }
    //3. in ra mang theo huong giam dan
    cout<<"Sap xep giam dan: "<<endl;
    for(int k=0;k<6;k++){
        cout<<mang[k]<<" "<<endl;
    }
    //4. in ra mang theo huong tang dan
    cout<<"Sap xep tang dan: "<<endl;
    for(int k=6-1;k>0;k--){
        cout<<mang[k]<<" "<<endl;
    }
}
int main()
{
    sapxep();
    return 0;
}
