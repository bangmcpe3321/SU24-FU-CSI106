#include <iostream>
using namespace std;//1. them thu vien
void timMinMax();//2.Khai bao ham
void timMinMax(){//3. dinh nghia ham
    int min,max;//khai bao 2 bien min max
    cout<<"Nhap mang: "<<endl;
    int mang[6];//mang nhap lieu
    for(int i=0;i<6;i++){
        cin>>mang[i];
    }
    max=mang[0];
    min=mang[0];
    for(int i=0;i<6;i++){
        if(mang[i]>max){
            max=mang[i];
        }
        if(mang[i]<min){
            min=mang[i];
        }
    }
    cout<<"Max la: "<<max<<endl;
    cout<<"Min la: "<<min<<endl;
}
int main()
{
    timMinMax();//4. goi ham
    return 0;
}
