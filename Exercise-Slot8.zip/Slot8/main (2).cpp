#include <iostream>
using namespace std;
void doiCho(int* a,int* b);
void doiCho(int* a,int* b){
    int tam;
    tam=*a;
    *a=*b;
    *b=tam;
}
int main()
{
    int a,b;
    cout<<"a="; cin>>a;
    cout<<"b="; cin>>b;
    doiCho(&a,&b);
    cout<<"a sau khi doi cho = "<<a<<endl;
    cout<<"b sau khi doi cho ="<<b<<endl;
    return 0;
}
