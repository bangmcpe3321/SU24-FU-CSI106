#Binary search algorithm
def binary_search(numbers,target):
    low,high=0, len(numbers)-1
    while low<=high:
        #tinh chi so trung binh cua dai hien tai
        mid=(low+high)//2
        if numbers[mid]==target:
            return mid
        elif numbers[mid] < target:
            low=mid+1
        else:
            high=mid-1
    return -1
    

print(binary_search([4,3,5,2,1,-2],5))
        