#Recuresuve algorithm
def factorial_recuresive(n):
   if n==0:
       return 1
   else:
        return n*factorial_recuresive(n-1)
   

print(factorial_recuresive(6))
        