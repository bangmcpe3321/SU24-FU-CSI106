#algorithm for Finding the smallest number
def find_smallest(numbers):
    smallest=numbers[0]
    for number in numbers:
        if number < smallest:
            smallest=number
    return smallest
print(find_smallest([3,5,2,9,1]))