#algorithm for Finding the largest number
def find_largest(numbers):
    largest=numbers[0]
    for number in numbers:
        if number > largest:
            largest=number
    return largest
print(find_largest([3,5,2,9,1]))