#Linear search algorithm
def linear_search(numbers, target):
    #find location of element that has value equal number
    for i, number in enumerate(numbers):
        if number==target:
            return i
    return -1

print(linear_search([3,5,2,1,-2],5))
        